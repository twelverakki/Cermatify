import java.util.*;

public abstract class SoalGenerator {
    public abstract List<Character> generateRandomLetters();
}
